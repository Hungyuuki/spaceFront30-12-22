export {};

declare global {
  interface Window {
    api: any; // turn off type checking
  }
}
